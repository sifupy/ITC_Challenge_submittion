# ITC_Chllenge_submittion 

## make sure you submit before 16:00 Tuesday november 14th 

# steps to fork:
 #### 1-Click on the "Fork" button in the top-right corner.
 #### 2-Open a terminal or command prompt on your local machine and navigate to your project and write:
 ```
  git init
  git add .
  git commit -m "descreption"
  git branch -M main
  git remote add origin https://github.com/your user name/ITC_Chellenge_submittion.git
  git push -u origin main
 ```
